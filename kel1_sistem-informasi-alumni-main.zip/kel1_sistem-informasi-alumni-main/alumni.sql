-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Jan 2024 pada 05.21
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alumni`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_user`
--

CREATE TABLE `data_user` (
  `id_data_user` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `id_guru` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id_guru`, `nama`, `foto`, `email`, `deskripsi`) VALUES
('05c19749-afbb-11ee-98f0-0a0027000008', 'Alvin Kesuma Wijaya', 'ipk7QtebDv5hQdbcFvcvtM4eRUEa0eSRbB71pkVW.jpg', 'alvin22si@mahasiswa.pcr.ac.id', 'Guru IPS'),
('0e2c44a6-9f70-11ee-b87e-0a0027000009', 'Alfiyanisa Maulida', 'PPVcliF00aRvNFcWVMhcUnVQSbyISucxjCchAPF6.jpg', 'alfiyanisa22si@mahasiswa.pcr.ac.id', 'Guru IPA'),
('1e9f6378-99e9-11ee-974a-0a0027000009', 'Azmi Fadhillah', 'cwyd60D1dqBLQNyyi3jssfamP6v7kr0mj4FPbeci.jpg', 'azmi22si@mahasiswa.pcr.ac.id', 'Guru Olahraga'),
('3b93d49c-9d5b-11ee-a45c-0a0027000009', 'Wahyu Ikhsan', 'yj0ZoHZrOJCJ9nG7rQ79vacodVXUPu2KdR4r8fIg.jpg', 'ikhsan22si@mahasiswa.pcr.ac.id', 'Guru PKN'),
('fb52f939-99e6-11ee-974a-0a0027000009', 'Alvin Kesuma Wijaya', '7TtOkwIHJvklecIQd2iFwH8OIwFXYV980HGHuo7t.jpg', 'alvin22si@mahasiswa.pcr.ac.id', 'Guru Sejarah Peminatan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `lowongan_pekerjaan`
--

CREATE TABLE `lowongan_pekerjaan` (
  `id_lowongan_pekerjaan` varchar(255) NOT NULL,
  `nama_perusahaan` varchar(255) NOT NULL,
  `nama_pekerjaan` varchar(255) NOT NULL,
  `posisi_pekerjaan` varchar(255) NOT NULL,
  `kontak` varchar(255) NOT NULL,
  `tanggal_pendaftaran` date NOT NULL,
  `tanggal_penutupan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `lowongan_pekerjaan`
--

INSERT INTO `lowongan_pekerjaan` (`id_lowongan_pekerjaan`, `nama_perusahaan`, `nama_pekerjaan`, `posisi_pekerjaan`, `kontak`, `tanggal_pendaftaran`, `tanggal_penutupan`) VALUES
('316db5e7-9fe1-11ee-b37a-0a0027000009', 'Pertamina', 'Project Manajers', 'Anggota Divisi', '082170843596', '2023-12-15', '2023-12-30'),
('b09fda84-a005-11ee-9463-0a0027000009', 'PT.Riau Andalan Pulp Paper', 'Desaigner UI/UX', 'Kepala Divisi Desainer', 'alvinkesumawijaya21@gmail.com', '2023-12-21', '2024-01-06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pekerjaan_alumni`
--

CREATE TABLE `pekerjaan_alumni` (
  `id_pekerjaan_alumni` varchar(255) NOT NULL,
  `id_siswa` varchar(255) NOT NULL,
  `tempat_kerja` varchar(255) NOT NULL,
  `jabatan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pekerjaan_alumni`
--

INSERT INTO `pekerjaan_alumni` (`id_pekerjaan_alumni`, `id_siswa`, `tempat_kerja`, `jabatan`) VALUES
('f70a3bfb-b0f7-11ee-9f95-0a0027000008', '1fc3be26-b0f5-11ee-9f95-0a0027000008', 'PT. Riau Andalan Pulp Paper', 'Cashier');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perkuliahan_alumni`
--

CREATE TABLE `perkuliahan_alumni` (
  `id_perkuliahan_alumni` varchar(255) NOT NULL,
  `id_siswa` varchar(255) NOT NULL,
  `perguruan_tinggi` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `jurusan` varchar(255) NOT NULL,
  `provinsi` varchar(255) NOT NULL,
  `jalur` varchar(255) NOT NULL,
  `tahun` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `perkuliahan_alumni`
--

INSERT INTO `perkuliahan_alumni` (`id_perkuliahan_alumni`, `id_siswa`, `perguruan_tinggi`, `kategori`, `jurusan`, `provinsi`, `jalur`, `tahun`) VALUES
('cbf571ce-b0f3-11ee-9f95-0a0027000008', 'f91b7ae6-b0ea-11ee-9f95-0a0027000008', 'Politeknik Caltex Riau', 'PTS', 'Sistem Informasi', 'Pekanbaru/Riau', 'PSUD', 2022),
('eb42a6d0-b0fc-11ee-9f95-0a0027000008', '1fc3be26-b0f5-11ee-9f95-0a0027000008', 'Politeknik Caltex Riau', 'PTN', 'Sistem Informasi', 'Pekanbaru/Riau', 'PSUD', 21);

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `nim` varchar(25) NOT NULL,
  `angkatan` int(10) NOT NULL,
  `kelas` varchar(25) NOT NULL,
  `jurusan` varchar(25) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nama`, `foto`, `nim`, `angkatan`, `kelas`, `jurusan`, `status`) VALUES
('1fc3be26-b0f5-11ee-9f95-0a0027000008', 'Alfiyanisa Maulida', 'BqEhYSVwockEl8uEcPhWrac8woIj8MwClL7fjGzv.jpg', '2257301008', 2016, '12', 'IPA', 'Kuliah'),
('f91b7ae6-b0ea-11ee-9f95-0a0027000008', 'Alvin Kesuma Wijaya', 'PpX4m8HtmRl9cNyNmdBxZ9APwQkBO5vKCtT9y1Qy.jpg', '2257301012', 2019, '12', 'IPS', 'Kerja');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`user_id`, `name`, `username`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Alvin Kesuma Wijaya', 'Alvin', '$2y$10$CM.d1xxM23qEJwrs4edVMOy77pQQexwmS7ssYQLdC7nh15N1X0kf6', '2023-11-30 00:08:00', '2024-01-03 17:39:11'),
(4, 'Azmi Fadhillah', 'Azmi', '$2y$10$zSBx11Y6PbbwjYiTT8D5suI89zoXGo3d8XLFB9GAiLuoCznTa1AZC', '2023-12-02 18:44:30', '2023-12-02 18:44:30'),
(14, 'Danny', 'Danny', '$2y$10$/C4sssxlLbeTEAzKbZLgju/mw0vphF2xDbATB/ngBH5EqZZRkueNe', '2024-01-03 11:44:13', '2024-01-03 11:44:13'),
(18, 'Fiya', 'Fiya', '$2y$10$Mwx/qQ2CtqFC.ksaAI8wxOqCArnJJmlkcTenb0uhaM0LiwuTNPRp2', '2024-01-03 17:37:25', '2024-01-03 17:37:25'),
(19, 'Ikhsan', 'Ikhsan', '$2y$10$T4aFL8D0f0mnxfvowxmQ.uWyLU2vM2tdIDZrNhawrTMEc.BlYI9.6', '2024-01-03 17:43:14', '2024-01-03 17:43:14');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_user`
--
ALTER TABLE `data_user`
  ADD PRIMARY KEY (`id_data_user`);

--
-- Indeks untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`id_guru`);

--
-- Indeks untuk tabel `lowongan_pekerjaan`
--
ALTER TABLE `lowongan_pekerjaan`
  ADD PRIMARY KEY (`id_lowongan_pekerjaan`);

--
-- Indeks untuk tabel `pekerjaan_alumni`
--
ALTER TABLE `pekerjaan_alumni`
  ADD PRIMARY KEY (`id_pekerjaan_alumni`),
  ADD KEY `id_siswa` (`id_siswa`);

--
-- Indeks untuk tabel `perkuliahan_alumni`
--
ALTER TABLE `perkuliahan_alumni`
  ADD PRIMARY KEY (`id_perkuliahan_alumni`),
  ADD KEY `id_siswa` (`id_siswa`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `tb_user_username_unique` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `user_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pekerjaan_alumni`
--
ALTER TABLE `pekerjaan_alumni`
  ADD CONSTRAINT `pekerjaan_alumni_ibfk_1` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `perkuliahan_alumni`
--
ALTER TABLE `perkuliahan_alumni`
  ADD CONSTRAINT `perkuliahan_alumni_ibfk_1` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
