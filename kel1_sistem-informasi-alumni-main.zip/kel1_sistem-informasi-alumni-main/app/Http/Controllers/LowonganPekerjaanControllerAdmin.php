<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class LowonganPekerjaanControllerAdmin extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from lowongan_pekerjaan order by tanggal_pendaftaran desc"));
        return view('admin/lowongan_pekerjaan.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin/lowongan_pekerjaan.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama_perusahaan' => 'required',
            'nama_pekerjaan' => 'required',
            'posisi_pekerjaan' => 'required',
            'kontak' => 'required',
            'tanggal_pendaftaran' => 'required',
            'tanggal_penutupan' => 'required'
        ]);


        DB::insert(
            "INSERT INTO `lowongan_pekerjaan` (`id_lowongan_pekerjaan`, `nama_perusahaan`, `nama_pekerjaan`, `posisi_pekerjaan`, `kontak`, `tanggal_pendaftaran`, `tanggal_penutupan`) VALUES (uuid(), ?, ?, ?, ?, ?, ?)",
            [
                $request->nama_perusahaan,
                $request->nama_pekerjaan,
                $request->posisi_pekerjaan,
                $request->kontak,
                $request->tanggal_pendaftaran,
                $request->tanggal_penutupan
            ]
        );

        return redirect()->route('lowongan_pekerjaan.index')->with(['success' => 'Data Berhasil Disimpan']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id_lowongan_pekerjaan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id_lowongan_pekerjaan)
    {
        $data = DB::table('lowongan_pekerjaan')->where('id_lowongan_pekerjaan', $id_lowongan_pekerjaan)->first();
        return view('admin/lowongan_pekerjaan.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id_lowongan_pekerjaan)
    {
        $this->validate($request, [
            'nama_perusahaan' => 'required',
            'nama_pekerjaan' => 'required',
            'posisi_pekerjaan' => 'required',
            'kontak' => 'required',
            'tanggal_pendaftaran' => 'required',
            'tanggal_penutupan' => 'required'
        ]);


        DB::update("UPDATE lowongan_pekerjaan SET nama_perusahaan=?, nama_pekerjaan=?, posisi_pekerjaan=?, kontak=?, tanggal_pendaftaran=?, tanggal_penutupan=? WHERE id_lowongan_pekerjaan=?", [
            $request->nama_perusahaan,
            $request->nama_pekerjaan,
            $request->posisi_pekerjaan,
            $request->kontak,
            $request->tanggal_pendaftaran,
            $request->tanggal_penutupan,
            $id_lowongan_pekerjaan
        ]);

        return redirect()->route('lowongan_pekerjaan.index')->with(['success' => 'Data Berhasil Diupdate!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_lowongan_pekerjaan)
    {
        DB::table('lowongan_pekerjaan')->where('id_lowongan_pekerjaan', $id_lowongan_pekerjaan)->delete();

        // Redirect to index
        return redirect()->route('lowongan_pekerjaan.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
