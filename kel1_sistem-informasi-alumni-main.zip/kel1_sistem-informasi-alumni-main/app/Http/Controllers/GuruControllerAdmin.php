<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class GuruControllerAdmin extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from guru order by nama asc"));
        return view('admin/guru.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin/guru.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'foto' => 'image|mimes:jpeg,png,jpg,gif,svg|max:5120',
            'email' => 'required',
            'deskripsi' => 'required'
        ]);

        // Upload image 
        $image = $request->file('foto');
        $image->storeAs('public/guru', $image->hashName());

        DB::insert(
            "INSERT INTO `guru` (`id_guru`, `nama`,`foto`, `email`, `deskripsi`) VALUES (uuid(), ?, ?, ?, ?)",
            [
                $request->nama,
                $image->hashName(),
                $request->email,
                $request->deskripsi
            ]
        );

        return redirect()->route('guru.index')->with(['success' => 'Data Berhasil Disimpan']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id_guru)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id_guru)
    {
        $data = DB::table('guru')->where('id_guru', $id_guru)->first();
        return view('admin/guru.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id_guru)
    {
        $request->validate([
            'nama' => 'required',
            'foto' => 'image|mimes:jpeg,png,jpg,gif,svg|max:5120',
            'email' => 'required',
            'deskripsi' => 'required'
        ]);

        // Cek apakah ada update atau tidak
        if ($request->file('foto')) {
            $image = $request->file('foto');
            $image->storeAs('public/guru', $image->hashName());


            DB::update(
                "UPDATE `guru` SET `nama`=?,`email`=?,`deskripsi`=?,`foto`=? WHERE id_guru=?",
                [$request->nama, $request->email, $request->deskripsi, $image->hashName(), $id_guru]
            );
        } else {
            DB::update(
                "UPDATE `guru` SET `nama`=?,`email`=?,`deskripsi`=? WHERE id_guru=?",
                [$request->nama, $request->email, $request->deskripsi, $id_guru]
            );
        }
        return redirect()->route('guru.index')->with(['success' => 'Data Berhasil Diupdate!']);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_guru)
    {
        DB::table('guru')->where('id_guru', $id_guru)->delete();

        // Redirect to index
        return redirect()->route('guru.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
