<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class PekerjaanAlumniController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from pekerjaan_alumni INNER JOIN siswa ON siswa.id_siswa=pekerjaan_alumni.id_siswa order by angkatan desc"));
        return view('AlumniSMAITAl-Ittihad/pekerjaan_alumni.index', compact('data'));
    }
}
