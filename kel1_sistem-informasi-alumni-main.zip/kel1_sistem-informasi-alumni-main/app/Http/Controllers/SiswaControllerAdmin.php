<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class SiswaControllerAdmin extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from siswa order by nama asc"));
        return view('admin/siswa.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin/siswa.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'foto' => 'image|mimes:jpeg,png,jpg,gif,svg|max:5120',
            'nim' => 'required',
            'angkatan' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
            'status' => 'required'
        ]);

        // Upload image 
        $image = $request->file('foto');
        $image->storeAs('public/siswa', $image->hashName());

        DB::insert(
            "INSERT INTO `siswa` (`id_siswa`, `nama`,`foto`, `nim`, `angkatan`, `kelas`, `jurusan`, `status`) VALUES (uuid(), ?, ?, ?, ?, ?, ?, ?)",
            [
                $request->nama,
                $image->hashName(),
                $request->nim,
                $request->angkatan,
                $request->kelas,
                $request->jurusan,
                $request->status
            ]
        );

        return redirect()->route('siswa.index')->with(['success' => 'Data Berhasil Disimpan']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id_siswa)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id_siswa)
    {
        $data = DB::table('siswa')->where('id_siswa', $id_siswa)->first();
        return view('admin/siswa.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id_siswa)
    {
        $request->validate([
            'nama' => 'required',
            'foto' => 'image|mimes:jpeg,png,jpg,gif,svg|max:5120',
            'nim' => 'required',
            'angkatan' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
            'status' => 'required'
        ]);

        // Cek apakah ada update atau tidak
        if ($request->file('foto')) {
            $image = $request->file('foto');
            $image->storeAs('public/siswa', $image->hashName());


            DB::update(
                "UPDATE `siswa` SET `nama`=?,`nim`=?,`angkatan`=?,`kelas`=?,`jurusan`=?,`status`=?,`foto`=? WHERE id_siswa=?",
                [$request->nama, $request->nim, $request->angkatan, $request->kelas, $request->jurusan, $request->status, $image->hashName(), $id_siswa]
            );
        } else {
            DB::update(
                "UPDATE `siswa` SET `nama`=?,`nim`=?,`angkatan`=?,`kelas`=?,`jurusan`=?,`status`=? WHERE id_siswa=?",
                [$request->nama, $request->nim, $request->angkatan, $request->kelas, $request->jurusan, $request->status, $id_siswa]
            );
        }
        return redirect()->route('siswa.index')->with(['success' => 'Data Berhasil Diupdate!']);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_siswa)
    {
        DB::table('siswa')->where('id_siswa', $id_siswa)->delete();

        // Redirect to index
        return redirect()->route('siswa.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
