<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class PekerjaanAlumniControllerAdmin extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from pekerjaan_alumni INNER JOIN siswa ON siswa.id_siswa=pekerjaan_alumni.id_siswa"));
        return view('admin/pekerjaan_alumni.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = DB::select(DB::raw("SELECT * FROM siswa WHERE status='kerja' AND id_siswa NOT IN (SELECT id_siswa FROM pekerjaan_alumni)"));
        return view('admin/pekerjaan_alumni.create', compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'tempat_kerja' => 'required',
            'jabatan' => 'required'
        ]);

        // Upload image 
        //$image = $request->file('foto');
        //$image->storeAs('public/pekerjaan_alumni', $image->hashName());

        DB::insert(
            "INSERT INTO `pekerjaan_alumni` (`id_pekerjaan_alumni`,`id_siswa`, `tempat_kerja`, `jabatan`) VALUES (uuid(), ?, ?, ?)",
            [
                $request->id_siswa,
                $request->tempat_kerja,
                $request->jabatan
            ]
        );

        return redirect()->route('pekerjaan_alumni.index')->with(['success' => 'Data Berhasil Disimpan']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id_pekerjaan_alumni)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id_pekerjaan_alumni)
    {
        $data = DB::table('pekerjaan_alumni')->where('id_pekerjaan_alumni', $id_pekerjaan_alumni)->first();
        return view('admin/pekerjaan_alumni.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id_pekerjaan_alumni)
    {
        $this->validate($request, [
            'tempat_kerja' => 'required',
            'jabatan' => 'required'
        ]);


        //cek update foto
        DB::update(
            "UPDATE `pekerjaan_alumni` SET `tempat_kerja`=?,`jabatan`=? WHERE id_pekerjaan_alumni=?",
            [$request->tempat_kerja, $request->jabatan, $id_pekerjaan_alumni]
        );
        return redirect()->route('pekerjaan_alumni.index')->with(['success' => 'Data Berhasil Diupdate!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_pekerjaan_alumni)
    {
        DB::table('pekerjaan_alumni')->where('id_pekerjaan_alumni', $id_pekerjaan_alumni)->delete();

        // Redirect to index
        return redirect()->route('pekerjaan_alumni.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
