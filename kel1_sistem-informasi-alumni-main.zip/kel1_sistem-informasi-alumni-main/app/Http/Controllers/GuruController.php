<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class GuruController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from guru order by nama asc"));
        return view('AlumniSMAITAl-Ittihad/guru.index', compact('data'));
    }
}
