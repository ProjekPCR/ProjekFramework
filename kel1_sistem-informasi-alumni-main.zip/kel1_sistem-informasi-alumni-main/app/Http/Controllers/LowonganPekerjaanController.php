<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class LowonganPekerjaanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from lowongan_pekerjaan order by tanggal_pendaftaran desc"));
        return view('AlumniSMAITAl-Ittihad/lowongan_pekerjaan.index', compact('data'));
    }
}
