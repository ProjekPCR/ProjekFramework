<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\siswa;
use App\Models\perkuliahan;
use App\Models\pekerjaan;
use App\Models\lowongan;
use App\Models\guru;
use App\Models\pengguna;
use DB;

class BerandaControllerAdmin extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $conn = mysqli_connect("localhost", "root", "", "alumni");

        $get1 = mysqli_query($conn, "SELECT * FROM siswa");
        $count1 = mysqli_num_rows($get1);

        $get2 = mysqli_query($conn, "SELECT * FROM perkuliahan_alumni");
        $count2 = mysqli_num_rows($get2);

        $get3 = mysqli_query($conn, "SELECT * FROM pekerjaan_alumni");
        $count3 = mysqli_num_rows($get3);

        $get4 = mysqli_query($conn, "SELECT * FROM lowongan_pekerjaan");
        $count4 = mysqli_num_rows($get4);

        $get5 = mysqli_query($conn, "SELECT * FROM guru");
        $count5 = mysqli_num_rows($get5);

        $get6 = mysqli_query($conn, "SELECT * FROM tb_user");
        $count6 = mysqli_num_rows($get6);

        return view('admin/beranda.index', compact('count1', 'count2', 'count3', 'count4', 'count5', 'count6'));
    }
}
