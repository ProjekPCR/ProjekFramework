<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class PerkuliahanAlumniController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from perkuliahan_alumni INNER JOIN siswa ON siswa.id_siswa=perkuliahan_alumni.id_siswa order by angkatan desc"));
        return view('AlumniSMAITAl-Ittihad/perkuliahan_alumni.index', compact('data'));
    }
}
