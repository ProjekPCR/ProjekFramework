<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class PerkuliahanAlumniControllerAdmin extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::select(DB::raw("select * from perkuliahan_alumni INNER JOIN siswa ON siswa.id_siswa=perkuliahan_alumni.id_siswa"));
        return view('admin/perkuliahan_alumni.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = DB::select(DB::raw("SELECT * FROM siswa WHERE status='kuliah' AND id_siswa NOT IN (SELECT id_siswa FROM perkuliahan_alumni)"));
        return view('admin/perkuliahan_alumni.create', compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'perguruan_tinggi' => 'required',
            'kategori' => 'required',
            'jurusan' => 'required',
            'provinsi' => 'required',
            'jalur' => 'required',
            'tahun' => 'required'
        ]);

        // Upload image 
        // $image = $request->file('foto');
        // $image->storeAs('public/perkuliahan_alumni', $image->hashName());

        DB::insert(
            "INSERT INTO `perkuliahan_alumni` (`id_perkuliahan_alumni`, `id_siswa`, `perguruan_tinggi`, `kategori`, `jurusan`, `provinsi`, `jalur`, `tahun`) VALUES (uuid(),?, ?, ?, ?, ?, ?, ?)",
            [
                $request->id_siswa,
                $request->perguruan_tinggi,
                $request->kategori,
                $request->jurusan,
                $request->provinsi,
                $request->jalur,
                $request->tahun
            ]
        );

        return redirect()->route('perkuliahan_alumni.index')->with(['success' => 'Data Berhasil Disimpan']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id_perkuliahan_alumni)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id_perkuliahan_alumni)
    {
        $data = DB::table('perkuliahan_alumni')->where('id_perkuliahan_alumni', $id_perkuliahan_alumni)->first();
        return view('admin/perkuliahan_alumni.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id_perkuliahan_alumni)
    {
        $this->validate($request, [
            'perguruan_tinggi' => 'required',
            'kategori' => 'required',
            'jurusan' => 'required',
            'provinsi' => 'required',
            'jalur' => 'required',
            'tahun' => 'required'
        ]);


        //cek update foto
        DB::update(
            "UPDATE `perkuliahan_alumni` SET `perguruan_tinggi`=?,`kategori`=?,`jurusan`=?,`provinsi`=?,`jalur`=?,`tahun`=? WHERE id_perkuliahan_alumni=?",
            [$request->perguruan_tinggi, $request->kategori, $request->jurusan, $request->provinsi, $request->jalur, $request->tahun, $id_perkuliahan_alumni]
        );
        return redirect()->route('perkuliahan_alumni.index')->with(['success' => 'Data Berhasil Diupdate!']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_perkuliahan_alumni)
    {
        DB::table('perkuliahan_alumni')->where('id_perkuliahan_alumni', $id_perkuliahan_alumni)->delete();

        // Redirect to index
        return redirect()->route('perkuliahan_alumni.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
