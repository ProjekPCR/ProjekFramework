<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg sticky-top p-0">
    <a class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img style="width:90px; height:55px" src="/assets/images/logos/logo-al-ittihad-pekanbaru.png">
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="{{ url('AlumniSMAITAl-Ittihad/beranda')}}" class="nav-item nav-link">Beranda</a>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Alumni</a>
                <div class="dropdown-menu bg-light m-0">
                    <a href="{{ url('AlumniSMAITAl-Ittihad/perkuliahan_alumni')}}" class="dropdown-item">Perkuliahan Alumni</a>
                    <a href="{{ url('AlumniSMAITAl-Ittihad/pekerjaan_alumni')}}" class="dropdown-item">Pekerjaan Alumni</a>
                </div>
            </div>
            <a href="{{ url('AlumniSMAITAl-Ittihad/guru')}}" class="nav-item nav-link">Guru</a>
            <a href="{{ url('AlumniSMAITAl-Ittihad/lowongan_pekerjaan')}}" class="nav-item nav-link">Loker</a>
        </div>
    </div>
</nav>
<!-- Navbar End -->