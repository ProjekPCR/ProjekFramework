@extends('AlumniSMAITAl-Ittihad/layouts.main')
@section('isi')
<!doctype html>
<html lang="en">

@section('title')
Guru SMA IT Al-Ittihad
@endsection

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <table id="guru">
        <thead>
          <tr>
            <th scope="col" width="200px">Nama</th>
            <th scope="col" width="50px">Foto</th>
            <th scope="col" width="150px">Email</th>
            <th scope="col" width="300px">Deskripsi</th>
          </tr>
        </thead>
        <tbody>
          @forelse ($data as $guru)
          <tr>
            <td>{{ $guru->nama }}</td>

            <td class="text-center">
              <img style="max-width:75px; max-height:100px" src="{{Storage::url('public/guru/') . $guru->foto }}" class="rounded" style="width: 150px">
            </td>

            <td>{{ $guru->email }}</td>

            <td>{!! $guru->deskripsi !!}</td>

          </tr>
          @empty
          <div class="alert alert-danger">
            Data guru belum tersedia.
          </div>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script>
    // message with toastr
    @php
    if (session()->has('success')) {
        echo "toastr.success('".session('success')."', 'BERHASIL!');";
    } elseif(session()->has('error')) {
        echo "toastr.error('".session('error')."', 'GAGAL!');";
    }
    @endphp

    $(document).ready(function() {
        $('#guru').DataTable();
    });
</script>
</body>

</html>
@endsection