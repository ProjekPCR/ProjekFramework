@extends('AlumniSMAITAl-Ittihad/layouts.main')
@section('isi')
<!doctype html>
<html lang="en">

@section('title')
Sistem Informasi Alumni SMA IT Al-Ittihad
@endsection

<body>
    <div class="row custom-margin-top">
        <div class="col-lg-4">
            <div class="col-lg-12">
                <div class="card overflow-hidden">
                    <div class="card-body p-4">
                        <h5 class="card-title mb-9 fw-semibold">Alumni Kuliah</h5>
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3> <?= $count2; ?> </h3>
                            </div>
                            <div class="col-4">
                                <div class="d-flex justify-content-center">
                                    <div><img style="width:50px; height:50px" src="../assets/icon/kuliah.png"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="col-lg-12">
                <div class="card overflow-hidden">
                    <div class="card-body p-4">
                        <h5 class="card-title mb-9 fw-semibold">Alumni Bekerja</h5>
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3> <?= $count3; ?> </h3>
                            </div>
                            <div class="col-4">
                                <div class="d-flex justify-content-center">
                                    <div><img style="width:50px; height:50px" src="../assets/icon/kerja.png"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="col-lg-12">
                <div class="card overflow-hidden">
                    <div class="card-body p-4">
                        <h5 class="card-title mb-9 fw-semibold">Lowongan Pekerjaan</h5>
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3> <?= $count4; ?> </h3>
                            </div>
                            <div class="col-4">
                                <div class="d-flex justify-content-center">
                                    <div><img style="width:50px; height:50px" src="../assets/icon/lowonganpekerjaan.png"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="col-lg-12">
                <div class="card overflow-hidden">
                    <div class="card-body p-4">
                        <h5 class="card-title mb-9 fw-semibold">Guru</h5>
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3><?= $count5; ?></h3>
                            </div>
                            <div class="col-4">
                                <div class="d-flex justify-content-center">
                                    <div><img style="width:50px; height:50px" src="../assets/icon/guru.png"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
@endsection