@extends('AlumniSMAITAl-Ittihad/layouts.main')
@section('isi')
<!doctype html>
<html lang="en">

@section('title')
Lowongan Pekerjaan SMA IT Al-Ittihad
@endsection

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <table id="lowongan_pekerjaan">
        <thead>
          <tr>
            <th scope="col">Nama Perusahaan</th>
            <th scope="col">Nama Pekerjaan</th>
            <th scope="col">Posisi</th>
            <th scope="col">Kontak</th>
            <th scope="col">Pendaftaran</th>
            <th scope="col">Penutupan</th>
          </tr>
        </thead>
        <tbody>
          @forelse ($data as $lowongan_pekerjaan)
          <tr>

            <td>{{ $lowongan_pekerjaan->nama_perusahaan}}</td>

            <td>{{ $lowongan_pekerjaan->nama_pekerjaan}}</td>

            <td>{{ $lowongan_pekerjaan->posisi_pekerjaan}}</td>

            <td>{{ $lowongan_pekerjaan->kontak}}</td>

            <td>{{ $lowongan_pekerjaan->tanggal_pendaftaran}}</td>

            <td>{{ $lowongan_pekerjaan->tanggal_penutupan}}</td>

          </tr>
          @empty
          <div class="alert alert-danger">
            Data alumni belum

            Tersedia.

          </div>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script>
    // message with toastr
    @php
    if (session()->has('success')) {
        echo "toastr.success('".session('success')."', 'BERHASIL!');";
    } elseif(session()->has('error')) {
        echo "toastr.error('".session('error')."', 'GAGAL!');";
    }
    @endphp

    $(document).ready(function() {
        $('#lowongan_pekerjaan').DataTable();
    });
</script>
</body>

</html>
@endsection