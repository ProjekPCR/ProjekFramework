@extends('AlumniSMAITAl-Ittihad/layouts.main')
@section('isi')
<!doctype html>
<html lang="en">

@section('title')
Perkuliahan Alumni SMA IT Al-Ittihad
@endsection

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <table id="perkuliahan_alumni">
        <thead>
          <tr>
            <th scope="col" width="200px">Nama</th>
            <th scope="col" width="50px">Foto</th>
            <th scope="col" width="25px">Angkatan</th>
            <th scope="col" width="190px">Perguruan Tinggi</th>
            <th scope="col" width="160px">PTN/PTS</th>
            <th scope="col" width="160px">Jurusan</th>
            <th scope="col" width="120px">Provinsi</th>
            <th scope="col" width="25px">Jalur</th>
            <th scope="col" width="25px">Tahun</th>
          </tr>
        </thead>
        <tbody>
          @forelse ($data as $perkuliahan_alumni)
          <tr>

            <td>{{ $perkuliahan_alumni->nama}}</td>

            <td class="text-center">
              <img style="max-width:75px; max-height:100px" src="{{Storage::url('public/siswa/') . $perkuliahan_alumni->foto }}" class="rounded" style="width: 150px">
            </td>

            <td>{{ $perkuliahan_alumni->angkatan}}</td>

            <td>{{ $perkuliahan_alumni->perguruan_tinggi}}</td>

            <td>{{ $perkuliahan_alumni->kategori}}</td>

            <td>{{ $perkuliahan_alumni->jurusan}}</td>

            <td>{{ $perkuliahan_alumni->provinsi}}</td>

            <td>{{ $perkuliahan_alumni->jalur}}</td>

            <td>{{ $perkuliahan_alumni->tahun}}</td>

          </tr>
          @empty
          <div class="alert alert-danger">
            Data alumni belum

            Tersedia.

          </div>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script>
    // message with toastr
    @php
    if (session()->has('success')) {
        echo "toastr.success('".session('success')."', 'BERHASIL!');";
    } elseif(session()->has('error')) {
        echo "toastr.error('".session('error')."', 'GAGAL!');";
    }
    @endphp

    $(document).ready(function() {
        $('#perkuliahan_alumni').DataTable();
    });
</script>
</body>

</html>
@endsection