@extends('admin/layouts.main')
@section('isi')

<body>
    <div class="row custom-margin-top">
        <div class="col-md-12">
            <div class="card w-100">
                <div class="card-body">
                    <form action="{{ route('lowongan_pekerjaan.update', $data->id_lowongan_pekerjaan) }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="form-group">
                            <label class="font-weight-bold">Nama Perusahaan</label>
                            <input type="text" class="form-control @error('nama_perusahaan') is-invalid @enderror" name="nama_perusahaan" placeholder="Nama Perusahaan" value="{{ $data->nama_perusahaan }}" autocomplete="off">
                            <!-- error message untuk Nama Perusahaan -->
                            @error('nama_perusahaan')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Nama Pekerjaan</label>
                            <input type="text" class="form-control @error('nama_pekerjaan') is-invalid @enderror" name="nama_pekerjaan" placeholder="Nama Pekerjaan" value="{{ $data->nama_pekerjaan }}" autocomplete="off">
                            <!-- error message untuk Nama Pekerjaan -->
                            @error('nama_pekerjaan')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Posisi Pekerjaan</label>
                            <input type="text" class="form-control @error('posisi_pekerjaan') is-invalid @enderror" name="posisi_pekerjaan" placeholder="Posisi Pekerjaan" value="{{ $data->posisi_pekerjaan }}" autocomplete="off">
                            <!-- error message untuk Posisi Pekerjaan -->
                            @error('posisi_pekerjaan')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Kontak</label>
                            <input type="text" class="form-control @error('kontak') is-invalid @enderror" name="kontak" placeholder="Kontak" value="{{ $data->kontak }}" autocomplete="off">
                            <!-- error message untuk Kontak -->
                            @error('kontak')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Pendaftaran</label>
                            <input type="date" class="form-control @error('tanggal_pendaftaran') is-invalid @enderror" name="tanggal_pendaftaran" placeholder="Masukkan tanggal pendaftaran" value="{{ $data->tanggal_pendaftaran }}" autocomplete="off">
                            <!-- error message untuk Tanggal Pendaftaran -->
                            @error('tanggal_pendaftaran')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Penutupan</label>
                            <input type="date" class="form-control @error('tanggal_penutupan') is-invalid @enderror" name="tanggal_penutupan" placeholder="Masukkan tanggal penutupan" value="{{ $data->tanggal_penutupan }}" autocomplete="off">
                            <!-- error message untuk Tanggal Penutupan -->
                            @error('tanggal_penutupan')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>

                        <button type="reset" class="btn btn-md btn-warning">RESET</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</body>
@endsection