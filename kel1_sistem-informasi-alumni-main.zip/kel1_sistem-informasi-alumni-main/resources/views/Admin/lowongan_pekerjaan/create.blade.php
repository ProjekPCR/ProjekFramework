@extends('admin/layouts.main')
@section('isi')

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <div class="card w-100">
        <div class="card-body">
          <form action="{{ route('lowongan_pekerjaan.store') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
              <label class="font-weight-bold">Nama Perusahaan</label>
              <input type="text" class="form-control @error('nama_perusahaan') is-invalid @enderror" name="nama_perusahaan" placeholder="Masukkan nama perusahaan" autocomplete="off">
              <!-- error message untuk nama perusahaan -->
              @error('nama_perusahaan')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Nama Pekerjaan</label>
              <input type="text" class="form-control @error('nama_pekerjaan') is-invalid @enderror" name="nama_pekerjaan" placeholder="Masukkan nama pekerjaan" autocomplete="off">
              <!-- error message untuk nama pekerjaan -->
              @error('nama_pekerjaan')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Posisi Pekerjaan</label>
              <input type="text" class="form-control @error('posisi_pekerjaan') is-invalid @enderror" name="posisi_pekerjaan" placeholder="Masukkan posisi pekerjaan" autocomplete="off">
              <!-- error message untuk posisi pekerjaan -->
              @error('posisi_pekerjaan')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Kontak</label>
              <input type="text" class="form-control @error('kontak') is-invalid @enderror" name="kontak" placeholder="Masukkan kontak yang bisa dihubungi" autocomplete="off">
              <!-- error message untuk Kontak -->
              @error('kontak')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Pendaftaran</label>
              <input type="date" class="form-control @error('tanggal_pendaftaran') is-invalid @enderror" name="tanggal_pendaftaran" placeholder="Masukkan tanggal pendaftaran" autocomplete="off">
              <!-- error message untuk tanggal pendaftaran -->
              @error('tanggal_pendaftaran')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Penutupan</label>
              <input type="date" class="form-control @error('tanggal_penutupan') is-invalid @enderror" name="tanggal_penutupan" placeholder="Masukkan tanggal penutupan" autocomplete="off">
              <!-- error message untuk tanggal penutupan -->
              @error('tanggal_penutupan')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
            <button type="reset" class="btn btn-md btn-warning">RESET</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  </div>
</body>
@endsection