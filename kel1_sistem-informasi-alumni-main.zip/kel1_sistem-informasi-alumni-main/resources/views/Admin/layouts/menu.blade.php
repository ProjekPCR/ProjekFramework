<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div>
        <div class="brand-logo d-flex align-items-center justify-content-between">
            <a class="text-nowrap logo-img">
                <img src="/assets/images/logos/Logo Al-Ittihad.png" width="180" alt="" />
            </a>
            <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                <i class="ti ti-x fs-8"></i>
            </div>
        </div>
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
            <ul id="sidebarnav">
                <li class="nav-small-cap">
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="{{ url('admin/beranda')}}" aria-expanded="false">
                        <span>
                            <img style="width:25px; height:25px" src="/assets/icon/beranda.png">
                        </span>
                        <span class="hide-menu">Beranda</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="{{ url('admin/siswa')}}" aria-expanded="false">
                        <span>
                            <img style="width:25px; height:25px" src="/assets/icon/siswa.png">
                        </span>
                        <span class="hide-menu">Siswa</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="{{ url('admin/perkuliahan_alumni')}}" aria-expanded="false">
                        <span>
                            <img style="width:25px; height:25px" src="/assets/icon/kuliah.png">
                        </span>
                        <span class="hide-menu">Perkuliahan Alumni</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="{{ url('admin/pekerjaan_alumni')}}" aria-expanded="false">
                        <span>
                            <img style="width:25px; height:25px" src="/assets/icon/kerja.png">
                        </span>
                        <span class="hide-menu">Pekerjaan Alumni</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="{{ url('admin/lowongan_pekerjaan')}}" aria-expanded="false">
                        <span>
                            <img style="width:25px; height:25px" src="/assets/icon/lowonganpekerjaan.png">
                        </span>
                        <span class="hide-menu">Lowongan Pekerjaan</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="{{ url('admin/guru')}}" aria-expanded="false">
                        <span>
                            <img style="width:25px; height:25px" src="/assets/icon/guru.png">
                        </span>
                        <span class="hide-menu">Guru</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link" href="{{ url('admin/user')}}" aria-expanded="false">
                        <span>
                            <img style="width:25px; height:25px" src="/assets/icon/pengguna.png">
                        </span>
                        <span class="hide-menu">Pengguna</span>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>