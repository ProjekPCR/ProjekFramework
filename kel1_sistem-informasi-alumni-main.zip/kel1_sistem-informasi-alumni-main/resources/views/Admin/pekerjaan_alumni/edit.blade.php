@extends('admin/layouts.main')
@section('isi')

<body>
    <div class="row custom-margin-top">
        <div class="col-md-12">
            <div class="card w-100">
                <div class="card-body">
                    <form action="{{ route('pekerjaan_alumni.update', $data->id_pekerjaan_alumni) }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="form-group">
                            <label class="font-weight-bold">Tempat Kerja</label>
                            <input type="text" class="form-control @error('tempat_kerja') is-invalid @enderror" name="tempat_kerja" placeholder="Masukkan tempat kerja" value="{{ $data->tempat_kerja }}" autocomplete="off">
                            <!-- error message untuk Tempat Kerja -->
                            @error('tempat_kerja')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Jabatan</label>
                            <input type="text" class="form-control @error('jabatan') is-invalid @enderror" name="jabatan" placeholder="Jabatan" value="{{ $data->jabatan }}" autocomplete="off">
                            <!-- error message untuk Jabatan -->
                            @error('jabatan')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>

                        <button type="reset" class="btn btn-md btn-warning">RESET</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</body>
@endsection