@extends('admin/layouts.main')
@section('isi')
<!doctype html>
<html lang="en">

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <div class="card w-100">
        <div class="card-body">
          <div class="d-sm-flex d-block align-items-center justify-content-between mb-9">
            <div class="mb-3 mb-sm-0">
              <h5 class="card-title fw-semibold">Guru SMA IT Al-Ittihad</h5>
            </div>
          </div>
          <a href="{{ route('guru.create') }}" class="btn btn-primary mb-3">TAMBAH</a>
          <table id="guru" class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" width="200px">Nama</th>
                <th scope="col" width="50px">Foto</th>
                <th scope="col" width="150px">Email</th>
                <th scope="col" width="300px">Deskripsi</th>
                <th scope="col" width="130px">Aksi</th>
              </tr>
            </thead>
            <tbody>
              @forelse ($data as $guru)
              <tr>
                <td>{{ $guru->nama }}</td>

                <td class="text-center">
                  <img style="max-width:75px; max-height:100px" src="{{Storage::url('public/guru/') . $guru->foto }}" class="rounded" style="width: 150px">
                </td>

                <td>{{ $guru->email }}</td>

                <td>{!! $guru->deskripsi !!}</td>

                <td class="text-center">
                  <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="{{route('guru.destroy', $guru->id_guru) }}" method="post">
                    <a href="{{route('guru.edit', $guru->id_guru) }}" class="btn btn-light"><img style="width:15px; height:15px" src="../assets/icon/edit.png"></a>

                    @csrf
                    @method('DELETE')

                    <button type="submit" class="btn btn-light"><img style="width:15px; height:15px" src="../assets/icon/rubbish-bin.png"></button>
                  </form>
                </td>
              </tr>
              @empty
              <div class="alert alert-danger">
                Data guru belum tersedia.
              </div>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script>
    // message with toastr
    @php
    if (session()->has('success')) {
        echo "toastr.success('".session('success')."', 'BERHASIL!');";
    } elseif(session()->has('error')) {
        echo "toastr.error('".session('error')."', 'GAGAL!');";
    }
    @endphp

    $(document).ready(function() {
        $('#guru').DataTable();
    });
</script>
</body>

</html>
@endsection