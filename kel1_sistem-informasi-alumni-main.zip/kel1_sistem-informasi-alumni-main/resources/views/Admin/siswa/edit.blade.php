@extends('admin/layouts.main')
@section('isi')

<body>
    <div class="row custom-margin-top">
        <div class="col-md-12">
            <div class="card w-100">
                <div class="card-body">
                    <form action="{{ route('siswa.update', $data->id_siswa) }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label class="font-weight-bold">Nama</label>
                            <input type="text" class="form-control @error('nama') is-invalid @enderror" name="nama" placeholder="Masukkan nama" value="{{ $data->nama }}" autocomplete="off">
                            <!-- error message untuk nama -->
                            @error('nama')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Foto</label>
                            <input type="file" class="form-control @error('image') is-invalid @enderror" name="foto" autocomplete="off">
                            <!-- error message untuk title -->
                            @error('foto')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">NIM</label>
                            <input type="number" class="form-control @error('nim') is-invalid @enderror" name="nim" value="{{ $data->nim }}" autocomplete="off">
                            <!-- error message untuk nim -->
                            @error('nim')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Angkatan</label>
                            <input type="number" class="form-control @error('angkatan') is-invalid @enderror" name="angkatan" value="{{ $data->angkatan }}" autocomplete="off">
                            <!-- error message untuk angkatan -->
                            @error('angkatan')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Kelas</label>
                            <input type="text" class="form-control @error('kelas') is-invalid @enderror" name="kelas" value="{{ $data->kelas }}" autocomplete="off">
                            <!-- error message untuk kelas -->
                            @error('kelas')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Jurusan</label>
                            <input type="text" class="form-control @error('jurusan') is-invalid @enderror" name="jurusan" value="{{ $data->jurusan }}" autocomplete="off">
                            <!-- error message untuk jurusan -->
                            @error('jurusan')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Status</label>
                            <select class="form-control @error('status') is-invalid @enderror" name="status" placeholder="Pilih Status">
                                <option value="" disabled>Pilih Status</option>
                                <option value="Pelajar" {{ $data->status === 'Pelajar' ? 'selected' : '' }}>Pelajar</option>
                                <option value="Kuliah" {{ $data->status === 'Kuliah' ? 'selected' : '' }}>Kuliah</option>
                                <option value="Kerja" {{ $data->status === 'Kerja' ? 'selected' : '' }}>Kerja</option>
                            </select>
                            <!-- error message untuk Status -->
                            @error('status')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                        <button type="reset" class="btn btn-md btn-warning">RESET</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</body>
@endsection