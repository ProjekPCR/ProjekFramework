@extends('admin/layouts.main')
@section('isi')

<div class="row custom-margin-top">
  <div class="col-md-12">
    <div class="card w-100">
      <div class="card-body">
        <form action="{{ route('siswa.store') }}" method="post" enctype="multipart/form-data">
          @csrf
          <div class="form-group">
            <label class="font-weight-bold">Nama</label>
            <input type="text" class="form-control @error('nama') is-invalid @enderror" name="nama" placeholder="Masukkan Nama" autocomplete="off">
            <!-- error message untuk nama -->
            @error('nama')
            <div class="alert alert-danger mt-2">
              {{ $message }}
            </div>
            @enderror
          </div>
          <br>
          <div class="form-group">
            <label class="font-weight-bold">Foto</label>
            <input type="file" class="form-control @error('image') is-invalid @enderror" name="foto" autocomplete="off">
            <!-- error message untuk title -->
            @error('foto')
            <div class="alert alert-danger mt-2">
              {{ $message }}
            </div>
            @enderror
          </div>
          <br>
          <div class="form-group">
            <label class="font-weight-bold">NIM</label>
            <input type="number" class="form-control @error('nim') is-invalid @enderror" name="nim" placeholder="Masukkan NIM" autocomplete="off">
            <!-- error message untuk NIM -->
            @error('nim')
            <div class="alert alert-danger mt-2">
              {{ $message }}
            </div>
            @enderror
          </div>
          <br>
          <div class="form-group">
            <label class="font-weight-bold">Angkatan</label>
            <input type="number" class="form-control @error('angkatan') is-invalid @enderror" name="angkatan" placeholder="Masukkan angkatan" autocomplete="off">
            <!-- error message untuk Angkatan -->
            @error('angkatan')
            <div class="alert alert-danger mt-2">
              {{ $message }}
            </div>
            @enderror
          </div>
          <br>
          <div class="form-group">
            <label class="font-weight-bold">Kelas</label>
            <input type="text" class="form-control @error('kelas') is-invalid @enderror" name="kelas" placeholder="Masukkan kelas" autocomplete="off">
            <!-- error message untuk Kelas -->
            @error('kelas')
            <div class="alert alert-danger mt-2">
              {{ $message }}
            </div>
            @enderror
          </div>
          <br>
          <div class="form-group">
            <label class="font-weight-bold">Jurusan</label>
            <input type="text" class="form-control @error('jurusan') is-invalid @enderror" name="jurusan" placeholder="Masukkan Jurusan" autocomplete="off">
            <!-- error message untuk jurusan -->
            @error('jurusan')
            <div class=" alert alert-danger mt-2">
              {{ $message }}
            </div>
            @enderror
          </div>
          <br>
          <div class="form-group">
            <label class="font-weight-bold">Status</label>
            <select class="form-control @error('status') is-invalid @enderror" name="status">
              <option value disable>Pilih Status</option>
              <option value="Pelajar">Pelajar</option>
              <option value="Kuliah">Kuliah</option>
              <option value="Kerja">Kerja</option>
            </select>
            <!-- error message untuk status -->
            @error('status')
            <div class="alert alert-danger mt-2">
              {{ $message }}
            </div>
            @enderror
          </div>
          <br>
          <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
          <button type="reset" class="btn btn-md btn-warning">RESET</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endsection