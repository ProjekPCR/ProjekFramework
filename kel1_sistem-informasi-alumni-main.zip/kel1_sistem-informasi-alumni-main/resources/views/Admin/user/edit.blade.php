@extends('admin/layouts.main')
@section('isi')

<body>
    <div class="row custom-margin-top">
        <div class="col-md-12">
            <div class="card w-100">
                <div class="card-body">
                    <form action="{{ route('user.update', $data->user_id) }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label class="font-weight-bold">Role</label>
                            <select class="form-control @error('role') is-invalid @enderror" name="role" placeholder="Role" value="{{ $data->role }}" autocomplete="off">
                                <option value="admin">Admin</option>
                                <option value="user">User</option>
                            </select>
                            <!-- error message untuk nama -->
                            @error('role')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Nama</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" placeholder="Masukkan nama" value="{{ $data->name }}" autocomplete="off">
                            <!-- error message untuk nama -->
                            @error('name')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Username</label>
                            <input type="text" class="form-control @error('username') is-invalid @enderror" name="username" value="{{ $data->username }}" autocomplete="off">
                            <!-- error message untuk username -->
                            @error('username')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Password</label>
                            <input type="password" class="form-control @error('password') is-invalid @enderror" name="password" value="{{ $data->password }}" autocomplete="off">
                            <!-- error message untuk password -->
                            @error('password')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Created At</label>
                            <input type="datetime-local" class="form-control @error('created_at') is-invalid @enderror" name="created_at" value="{{ $data->created_at }}" autocomplete="off">
                            <!-- error message untuk created_at -->
                            @error('created_at')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Updated At</label>
                            <input type="datetime-local" class="form-control @error('updated_at') is-invalid @enderror" name="updated_at" value="{{ $data->updated_at }}" autocomplete="off">
                            <!-- error message untuk updated_at -->
                            @error('updated_at')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
                        <button type="reset" class="btn btn-md btn-warning">RESET</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
</body>
@endsection