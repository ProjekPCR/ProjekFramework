@extends('admin/layouts.main')
@section('isi')

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <div class="card w-100">
        <div class="card-body">
          <form action="{{ route('user.store') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
              <label class="font-weight-bold">Nama</label>
              <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" placeholder="Masukkan Nama" autocomplete="off">
              <!-- error message untuk name -->
              @error('name')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Username</label>
              <input type="text" class="form-control @error('username') is-invalid @enderror" name="username" placeholder="Masukkan username" autocomplete="off">
              <!-- error message untuk username -->
              @error('username')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Password</label>
              <input type="password" class="form-control @error('password') is-invalid @enderror" name="password" placeholder="Masukkan password" autocomplete="off">
              <!-- error message untuk password -->
              @error('password')
              <div class=" alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Konfirmasi Password</label>
              <input type="password" class="form-control @error('password_confirmation') is-invalid @enderror" name="password_confirmation" placeholder="Masukkan konfirmasi password" autocomplete="off">
              <!-- error message untuk password -->
              @error('password_confirmation')
              <div class=" alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
            <button type="reset" class="btn btn-md btn-warning">RESET</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  </div>
</body>
@endsection