@extends('admin/layouts.main')
@section('isi')
<!doctype html>
<html lang="en">

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <div class="card w-100">
        <div class="card-body">
          <div class="d-sm-flex d-block align-items-center justify-content-between mb-9">
            <div class="mb-3 mb-sm-0">
              <h5 class="card-title fw-semibold">Pengguna Sistem</h5>
            </div>
          </div>
          <a href="{{ route('user.create') }}" class="btn btn-primary mb-3">TAMBAH</a>
          <table id="tb_user" class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" width="100px">Nama</th>
                <th scope="col" width="100px">Username</th>
                <th scope="col" width="100px">Password</th>
                <th scope="col" width="50px">Create at</th>
                <th scope="col" width="50px">Update at</th>
                <th scope="col" width="50px">Aksi</th>
              </tr>
            </thead>
            <tbody>
              @forelse ($data as $tb_user)
              <tr>
                <td>{{ $tb_user->name}}</td>

                <td>{{ $tb_user->username}}</td>

                <td>{{ $tb_user->password}}</td>

                <td>{{ $tb_user->created_at}}</td>

                <td>{{ $tb_user->updated_at}}</td>

                <td class="text-center">
                  <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="{{route('user.destroy', $tb_user->user_id) }}" method="post">
                    <a href="{{route('user.edit', $tb_user->user_id) }}" class="btn btn-light"><img style="width:15px; height:15px" src="../assets/icon/edit.png"></a>

                    @csrf
                    @method('DELETE')

                    <button type="submit" class="btn btn-light"><img style="width:15px; height:15px" src="../assets/icon/rubbish-bin.png"></button>
                  </form>
                </td>
              </tr>
              @empty
              <div class="alert alert-danger">
                Data user belum tersedia.
              </div>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script>
    // message with toastr
    @php
    if (session()->has('success')) {
        echo "toastr.success('".session('success')."', 'BERHASIL!');";
    } elseif(session()->has('error')) {
        echo "toastr.error('".session('error')."', 'GAGAL!');";
    }
    @endphp

    $(document).ready(function() {
        $('#tb_user').DataTable();
    });
</script>
</body>

</html>
@endsection