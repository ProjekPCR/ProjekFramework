@extends('admin/layouts.main')
@section('isi')

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <div class="card w-100">
        <div class="card-body">
          <form action="{{ route('perkuliahan_alumni.store') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
              <label class="font-weight-bold">Nama</label>
              <select class="form-control @error('data') is-invalid @enderror" name="id_siswa">
                <option disable value>Pilih Nama</option>
                @foreach($data as $item)
                <option value="{{ $item->id_siswa}}">{{ $item->nama}}</option>
                @endforeach
              </select>
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Perguruan Tinggi</label>
              <input type="text" class="form-control @error('perguruan_tinggi') is-invalid @enderror" name="perguruan_tinggi" placeholder="Masukkan perguruan tinggi" autocomplete="off">
              <!-- error message untuk perguruan tinggi -->
              @error('perguruan_tinggi')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">PTN/PTS</label>
              <select class="form-control @error('kategori') is-invalid @enderror" name="kategori">
                <option value disable>PTN/PTS</option>
                <option value="PTN">PTN</option>
                <option value="PTS">PTS</option>
              </select>
              <!-- error message untuk kategori -->
              @error('kategori')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Jurusan</label>
              <input type="text" class="form-control @error('jurusan') is-invalid @enderror" name="jurusan" placeholder="Masukkan jurusan" autocomplete="off">
              <!-- error message untuk jurusan -->
              @error('jurusan')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Provinsi</label>
              <input type="text" class="form-control @error('provinsi') is-invalid @enderror" name="provinsi" placeholder="Masukkan provinsi" autocomplete="off">
              <!-- error message untuk provinsi -->
              @error('provinsi')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Jalur</label>
              <input type="text" class="form-control @error('jalur') is-invalid @enderror" name="jalur" placeholder="Masukkan jalur" autocomplete="off">
              <!-- error message untuk jalur -->
              @error('jalur')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <div class="form-group">
              <label class="font-weight-bold">Tahun</label>
              <input type="number" class="form-control @error('tahun') is-invalid @enderror" name="tahun" placeholder="Masukkan tahun" autocomplete="off">
              <!-- error message untuk provinsi -->
              @error('tahun')
              <div class="alert alert-danger mt-2">
                {{ $message }}
              </div>
              @enderror
            </div>
            <br>
            <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
            <button type="reset" class="btn btn-md btn-warning">RESET</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
@endsection