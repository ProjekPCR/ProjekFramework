@extends('admin/layouts.main')
@section('isi')

<body>
    <div class="row custom-margin-top">
        <div class="col-md-12">
            <div class="card w-100">
                <div class="card-body">
                    <form action="{{ route('perkuliahan_alumni.update', $data->id_perkuliahan_alumni) }}" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="form-group">
                            <label class="font-weight-bold">Perguruan Tinggi</label>
                            <input type="text" class="form-control @error('perguruan_tinggi') is-invalid @enderror" name="perguruan_tinggi" placeholder="perguruan_tinggi" value="{{ $data->perguruan_tinggi }}" autocomplete="off">
                            <!-- error message untuk Perguruan Tinggi -->
                            @error('perguruan_tinggi')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">PTN/PTS</label>
                            <select class="form-control @error('kategori') is-invalid @enderror" name="kategori" placeholder="Pilih Kategori">
                                <option value="" disabled>PTN/PTS</option>
                                <option value="PTN" {{ $data->kategori === 'PTN' ? 'selected' : '' }}>PTN</option>
                                <option value="PTS" {{ $data->kategori === 'PTS' ? 'selected' : '' }}>PTS</option>
                            </select>
                            <!-- error message untuk Kategori -->
                            @error('kategori')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Jurusan</label>
                            <input type="text" class="form-control @error('jurusan') is-invalid @enderror" name="jurusan" placeholder="Jurusan" value="{{ $data->jurusan }}" autocomplete="off">
                            <!-- error message untuk Perguruan Tinggi -->
                            @error('jurusan')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Provinsi</label>
                            <input type="text" class="form-control @error('provinsi') is-invalid @enderror" name="provinsi" placeholder="Provinsi" value="{{ $data->provinsi }}" autocomplete="off">
                            <!-- error message untuk Provinsi -->
                            @error('provinsi')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Jalur</label>
                            <input type="text" class="form-control @error('jalur') is-invalid @enderror" name="jalur" placeholder="Jalur" value="{{ $data->jalur }}" autocomplete="off">
                            <!-- error message untuk Jalur -->
                            @error('jalur')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="font-weight-bold">Tahun</label>
                            <input type="text" class="form-control @error('tahun') is-invalid @enderror" name="tahun" placeholder="Tahun" value="{{ $data->tahun }}" autocomplete="off">
                            <!-- error message untuk Tahun -->
                            @error('tahun')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <br>
                        <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>

                        <button type="reset" class="btn btn-md btn-warning">RESET</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
@endsection