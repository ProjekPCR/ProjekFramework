@extends('admin/layouts.main')
@section('isi')
<!doctype html>
<html lang="en">

<body>
  <div class="row custom-margin-top">
    <div class="col-md-12">
      <div class="card w-100">
        <div class="card-body">
          <div class="d-sm-flex d-block align-items-center justify-content-between mb-9">
            <div class="mb-3 mb-sm-0">
              <h5 class="card-title fw-semibold">Alumni SMA IT Al-Ittihad</h5>
            </div>
          </div>
          <a href="{{ route('perkuliahan_alumni.create') }}" class="btn btn-primary mb-3">TAMBAH</a>
          <table id="perkuliahan_alumni" class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" width="200px">Nama</th>
                <th scope="col" width="50px">Foto</th>
                <th scope="col" width="25px">Angkatan</th>
                <th scope="col" width="190px">Perguruan Tinggi</th>
                <th scope="col" width="190px">PTN/PTS</th>
                <th scope="col" width="160px">Jurusan</th>
                <th scope="col" width="120px">Provinsi</th>
                <th scope="col" width="25px">Jalur</th>
                <th scope="col" width="25px">Tahun</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
              @forelse ($data as $perkuliahan_alumni)
              <tr>

                <td>{{ $perkuliahan_alumni->nama}}</td>

                <td class="text-center">
                  <img style="max-width:75px; max-height:100px" src="{{Storage::url('public/siswa/') . $perkuliahan_alumni->foto }}" class="rounded" style="width: 150px">
                </td>

                <td>{{ $perkuliahan_alumni->angkatan}}</td>

                <td>{{ $perkuliahan_alumni->perguruan_tinggi}}</td>

                <td>{{ $perkuliahan_alumni->kategori}}</td>

                <td>{{ $perkuliahan_alumni->jurusan}}</td>

                <td>{{ $perkuliahan_alumni->provinsi}}</td>

                <td>{{ $perkuliahan_alumni->jalur}}</td>

                <td>{{ $perkuliahan_alumni->tahun}}</td>

                <td class="text-center">
                  <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="{{route('perkuliahan_alumni.destroy', $perkuliahan_alumni->id_perkuliahan_alumni) }}" method="post">
                    <a href="{{route('perkuliahan_alumni.edit', $perkuliahan_alumni->id_perkuliahan_alumni) }}" class="btn btn-light"><img style="width:15px; height:15px" src="../assets/icon/edit.png"></a>

                    @csrf
                    @method('DELETE')

                    <button type="submit" class="btn btn-light"><img style="width:15px; height:15px" src="../assets/icon/rubbish-bin.png"></button>
                  </form>
                </td>
              </tr>
              @empty
              <div class="alert alert-danger">
                Data alumni belum

                Tersedia.

              </div>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script>
    // message with toastr
    @php
    if (session()->has('success')) {
        echo "toastr.success('".session('success')."', 'BERHASIL!');";
    } elseif(session()->has('error')) {
        echo "toastr.error('".session('error')."', 'GAGAL!');";
    }
    @endphp

    $(document).ready(function() {
        $('#perkuliahan_alumni').DataTable();
    });
</script>
</body>

</html>
@endsection